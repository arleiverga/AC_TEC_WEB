from django.http import HttpResponse
from django.shortcuts import render
def index(request):
	return render(request, "index.html")

# Valida request POST
def contato(request):
	if request.method == "POST":
		print("EMAIL: ",request.POST.get("plogin")," MENSAGEM: ",request.POST.get("pmensagem"))
	return render(request, "contato.html")

def login(request):
	if request.method == "POST":
		if request.POST.get("senha") == "teste123":
			print("Usuário<",request.POST.get("login"),"> Entrou com sucesso!")
			return render(request, "index.html")
		else:
			print("Usuário<",request.POST.get("login"),"> Digitou a senha errada!")
	return render(request, "login.html")